# AngularLeaflet
The above source code is part of [How to Use Leaflet In Angular Tutorial](https://codehandbook.org/use-leaflet-in-angular/) published on [CodeHandbook](https://codehandbook.org)

## Running the source code
```
git clone https://github.com/codehandbook/angular-leaflet
cd angular-leaflet
npm install
npm start
```
